#ifndef LOG_H
#define LOG_H

#include <string>

void writeLog(const std::string &message);

#endif
